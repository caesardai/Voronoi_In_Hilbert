import drawing.DrawingApplet;

public class Test2 {
	public static void main(String[] argv) {
		DrawingApplet.main(argv);
	}
}
