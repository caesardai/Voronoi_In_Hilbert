import drawing.DrawingApplet;

public class Test1 extends DrawingApplet {
	// public Test1() {}
	
	@Override
	public void settings() {
		size(800, 600);
	}
	
	public void run(String[] argv) {
		super.main(argv);
	}
	
	public static void main(String[] argv) {
		Test1 t = new Test1();
		t.run(argv);
	}

}
